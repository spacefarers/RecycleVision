#!/bin/sh

# function
get_sensor_id()
{
    # echo "use sensor $SENSOR_NAME"
    case $SENSOR_NAME in
        ov9732)
            SENSOR_ID=0
        ;;
        ov9286)
            SENSOR_ID=1
        ;;
        imx335)
            SENSOR_ID=2
        ;;
        imx219)
            SENSOR_ID=3
        ;;
        *)
            echo "not support sensor $SENSOR_NAME"
            SENSOR_ID=0
        ;;
    esac
}

# add ld rpath
export LD_LIBRARY_PATH=/lib64/tuning-server:$LD_LIBRARY_PATH

# add tuning-server path
export PATH=/app/tuning-server:$PATH

# tuning-server-exec

TUNINE_SERVER=tuning-server

# use network

# use uart device

UART_DEV=/dev/ttyS1

# sensor name

SENSOR_NAME=ov9732

# sensor name id

get_sensor_id

# cd mount

mkdir /app/tuning-server/mount

# run tuning server
echo $UART_DEV $SENSOR_ID | $TUNINE_SERVER
