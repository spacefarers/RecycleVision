%include <typemaps/attribute.swg>
