================
Help and support
================

Mailing List
============

There is a mailing list for this project:

	swupdate@googlegroups.com

Issue related to the project or to the documentation are discussed
here.

SWUpdate Flyer
==============

A short description about the project and the features (in English and German)
can be found in the `flyer <http://www.denx.de/en/pub/Software/WebHome/we-update.pdf>`_

Workshop and SWUpdate integration in project
============================================

For quick integration of SWUpdate in your project, you could be interested in the `Workshop <http://www.denx.de/wiki/Training2/WebHome#WorkshopSWUpdate>`_

Commercial support and board integration
========================================

You can contact me at sbabic@denx.de if you need professional support or you need help to get SWUpdate on your device.

Talks about SWUpdate
====================

       - `Software Update in Embedded Systems by Stefano Babic <http://events.linuxfoundation.org/sites/events/files/slides/SoftwareUpdateForEmbedded.pdf>`_
       - `Updating Embedded Linux devices in field by Chris Simmonds <http://de.slideshare.net/chrissimmonds/linux-fieldupdate2015>`_
       - `OpenEmbedded in the Real World by Scott Murray <https://elinux.org/images/7/74/Murray.pdf>`_
       - `[RFC] Device-side support for software update in AGL by Matt Porter <https://lists.linuxfoundation.org/pipermail/automotive-discussions/2016-May/002061.html>`_
       - `Open Source secure software updates for Linux-based IVI systems by Arthur Taylor <https://events.static.linuxfound.org/sites/events/files/slides/Open%20Source%20secure%20software%20updates%20for%20Linux-based%20IVI%20systems.pdf>`_
       - `How do you update your embedded Linux devices? by Daniel Sangorrin / Keijiro Yano <https://events.static.linuxfound.org/sites/events/files/slides/linuxcon-japan-2016-softwre-updates-sangorrin.pdf>`_
       - `Comparison of Linux Software Update Technologies by Matt Porter <https://elinux.org/images/3/31/Comparison_of_Linux_Software_Update_Technologies.pdf>`_
       - Software update for IoT: the current state of play by Chris Simmonds, ELCE 2016, `Slides <http://de.slideshare.net/chrissimmonds/software-update-for-iot-the-current-state-of-play>`_, 
         `Video <https://youtu.be/GZGnBK2NycI?list=PLbzoR-pLrL6pRFP6SOywVJWdEHlmQE51q>`_
       - OSS Remote Firmware Updates for IoT-like Projects by Silvano Cirujano Cuesta, ELCE 2016,
         `Slides ELCE 2016 <https://elinux.org/images/1/11/OSS_Remote_Firmware_Updates_for_IoT-like_Projects.pdf>`_, 
         `Video ELCE 2016 <https://youtu.be/vVS-ZRNE0Lc?list=PLbzoR-pLrL6pRFP6SOywVJWdEHlmQE51q>`_
       - System Upgrade with SWUpdate by Gabriel Huau, ELC 2017,
         `Slides ELC 2017 <http://events17.linuxfoundation.org/sites/events/files/slides/ELC2017_SWUpdate.pdf>`_,
         `Video ELC 2017 <https://www.youtube.com/watch?v=ePRTTfGJUI4&t=16s>`_
       - `BoF: Secure OTA Collaboration, by Ricardo Salveti and Alan Bennett, ELCE 2017 <https://elinux.org/images/0/0c/BoF_secure_ota_linux.pdf>`_
       - Orchestrated Android-Style System Upgrades for Embedded Linux by Diego Rondini, ELCE 2017,
         `Slides Android-Style <https://www.elinux.org/images/6/6d/UF_-_ELCE_2017_Presentation.pdf>`_,
         `Video Android-Style <https://www.youtube.com/watch?v=Za21QFJGvJ0>`_
       - Updating an Embedded System with SWUpdate Framework by Stefano Babic, ELCE 2017,
         `Slides ELCE 2017 <http://events17.linuxfoundation.org/sites/events/files/slides/SWUpdateELCE2017.pdf>`_,
         `Video ELCE 2017 <https://www.youtube.com/watch?v=6sKLH95g4Do>`_
       - Upgrading buildroot based devices with SWUpdate by Angelo Compagnucci, LinuxLab 2018,
         `Slides LinuxLab  2018 <https://www.slideshare.net/linuxlab_conf/angelo-compagnucci-upgrading-buildroot-based-devices-with-swupdate>`_,
         `Video LinuxLab 2018 <https://www.youtube.com/watch?v=8vv5Xf6dBKE>`_
       - Evolution of (OTA) Update in the IoT world by Stefano Babic, ELC 2019,
         `Slides ELC 2019 <https://www.slideshare.net/StefanoBabic/evolution-of-otaupdateintheiotworld>`_,
         `Video ELC 2019 <https://www.youtube.com/watch?v=WZHO18EhD7Y>`_

Useful references
=================

        - `Boundary Devices, Using SWUpdate to upgrade your system <https://boundarydevices.com/using-swupdate-upgrade-system>`_
        - `Présentation de Software Update (French) <http://www.linuxembedded.fr/2016/09/presentation-de-software-update>`_
        - `Easy OS upgrades with SWUpdate <http://warpx.io/blog/tutorial/easy-os-upgrades-swupdate>`_
        - `SWUpdate for feature-rich IoT applications <https://3mdeb.com/app-dev/swupdate-for-feature-rich-iot-applications/>`_
        - `Implement swupdate - replacing opkg based updating, VictronEnergy <https://github.com/victronenergy/venus/issues/27>`_
        - `Variscite, SWUpdate <http://www.variwiki.com/index.php?title=SWUpdate_Guide>`_
        - `Updating Embedded Linux Devices: SWUpdate <http://mkrak.org/2018/01/26/updating-embedded-linux-devices-part2/>`_
        - `Approach to Software Update Management, Pelux  <https://pelux.io/software-factory/PELUX-3.0/swf-blueprint/docs/articles/architecture/vert-config-SOTA.html>`_
        - `SOTA System, Pelux  <https://pelux.io/software-factory/PELUX-3.0/chapters/architecture/subsystems/SOTA/SOTA-system.html>`_
        - `Building a Linux system for the STM32MP1: remote firmware updates, Bootlin <https://bootlin.com/blog/tag/swupdate/>`_
