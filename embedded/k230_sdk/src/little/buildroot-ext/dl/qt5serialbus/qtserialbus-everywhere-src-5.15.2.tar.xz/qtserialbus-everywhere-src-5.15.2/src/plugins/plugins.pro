TEMPLATE = subdirs

SUBDIRS += canbus
